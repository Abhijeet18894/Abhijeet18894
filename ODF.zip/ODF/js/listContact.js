$(document).ready(() => {
    $('#get-contact').click((e) => {
        $.ajax({
            url: "http://localhost:3000/contactUs",
            method: "GET",
            dataType: 'json',
            success: (data) => {
                // const result = JSON.stringify(data);
                console.log(data);
                $.each(data, function (index, value) {
                    $('#contact-div').append(`
                        <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">${value.name}</h5>
                            <h6 class="card-subtitle mb-2 text-muted">${value.email}</h6>
                            <p class="card-text">${value.text}</p>
                            <button class="btn btn-danger" onclick="deleteContact(${value.id})">Delete</button>
                        </div>
                        </div>
                        `)
                })
            }
        });
    });
});

function deleteContact(id) {
    console.log(id);
    $.ajax({
        url: 'http://localhost:3000/contactUs/' + id,
        method: 'DELETE',
        dataType: 'application/json',
        success: (data) => {
            alert("User deleted successfully" + data);
        },
        // error: (e) => {
        //     alert("Please enter valid id: " + e);
        // }
    });
}