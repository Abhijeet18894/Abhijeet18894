// $(document).ready(() => {
//     $('#get-users').click((e) => {
//         $.ajax({
//             url: "http://localhost:3000/users/${id}",
//             method: "DELETE",
//             dataType: 'json',
//             success: (data) => {
//                 // const result = JSON.stringify(data);
//                 console.log(data);
//                 alert("User deleted successfully");

//             }
//         });
//     });
// });



// function deleteUser(id) {
//     $.ajax({
//         url: "http://localhost:3000/users/3",
//         method: "DELETE",
//         dataType: 'json',
//         success: (data) => {
//             // const result = JSON.stringify(data);
//             console.log(data);
//             alert("User deleted successfully");

//         }
//     });
// }