$(document).ready(() => {
    $('#get-users').click((e) => {
        $.ajax({
            url: "http://localhost:3000/users",
            method: "GET",
            dataType: 'json',
            success: (data) => {
                // const result = JSON.stringify(data);
                console.log(data);
                $.each(data, function (index, value) {
                    $('#table-body').append(`<tr>
                            <td>${value.id}</td>
                            <td>${value.firstName}</td>
                            <td>${value.lastName}</td>
                            <td>${value.username}</td>
                            <td>${value.actor}</td>
                            <td>${value.email}</td>
                            <td>${value.password}</td>
                            <td><button id="btn-modal" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#exampleModal") >Update</button></td>
                            <td><button class="btn btn-danger" onclick="deleteUser(${value.id})">Delete</button></td>
                        </tr>`)
                })
            }
        });
    });
});

function deleteUser(id) {
    console.log(id);
    $.ajax({
        url: 'http://localhost:3000/users/' + id,
        method: 'DELETE',
        dataType: 'application/json',
        success: (data) => {
            alert("User deleted successfully" + data);
        },
        // error: (e) => {
        //     alert("Please enter valid id: " + e);
        // }
    });
}

// function updateUser(id) {
//     console.log(id);
//     $.ajax({
//         url: "http://localhost:3000/users/" + id,
//         method: 'PUT',
//         dataType: 'json',
//         success: () => {
//             alert("User deleted successfully" + id);
//         },

//         error: (e) => {
//             alert("Error  invalid credentials: " + e);
//         }
//     });
// }






