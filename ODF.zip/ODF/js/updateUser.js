$(document).ready(() => {

    $('#modal-button-update').click((e) => {
        e.preventDefault();
        var firstname = $('#first-id').val();
        var lastname = $('#last-id').val();
        var email = $('#email-id').val();
        var actor = $('#actor-id').val();;
        var username = $('#username-id').val();
        var password = $('#pass-id').val();
        var userid = $('#user-id').val();

        console.log(firstname);
        console.log(lastname);
        console.log(email);
        console.log(username);
        console.log(password);
        console.log(userid);
        console.log(actor);

        if (firstname == "" && lastname == "" && email == "" && username == "" && password == "") {
            $('#message').html('Fill all the fields')
        }

        else if (firstname == "" || lastname == "" || email == "" || username == "" || password == "") {

            if (firstname == "") {
                $('#fname-s').html('please fill firstname');
            }
            else if (lastname == "") {
                $('#lname-s').html('please fill lastname');
            }
            else if (email == "") {
                $('#email-s').html('please fill email');
            }
            else if (username == "") {
                $('#uname-s').html('please fill username');
            }
            else if (password == "") {
                $('#pass-s').html('please enter password');
            }

        }

        //sending request to server
        else {
            $.ajax({
                url: "http://localhost:3000/users/" + userid,
                method: "PUT",
                data: {
                    "firstName": firstname,
                    "lastName": lastname,
                    "email": email,
                    "actor": actor,
                    "username": username,
                    "password": password
                },
                dataType: "json",
                success: (x) => {
                    alert(username + " Update is successful");
                    console.log(x);
                    window.location = "../html/listUsers.html"
                    return false;
                },
                error: (e) => {
                    alert("Error : " + e)
                }
            })
        }



    })




})

