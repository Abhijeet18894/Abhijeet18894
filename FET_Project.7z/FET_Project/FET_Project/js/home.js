function getQusetions() {
    qusetionsListResult = JSON.parse(QusetionsList());
    let str = '<div class="container1"><div class="row">';
    for (let i = 0; i < qusetionsListResult.length; i++) {
        if(qusetionsListResult[i].approved == 'Approved by Admin'){
        str +=
         '<div class="card " style="text-align:left;background-color:lightblue;">'+
            '<img src="../Images/question.png"  style="width:30px;height:30px" alt="...">';
             str += '<p>' + (i+1) +'. Question</p>'+
                '<h5 class="card-title">Category: '+qusetionsListResult[i].categoryName +'</h5>'+
                '<p class="card-text">Question: '+qusetionsListResult[i].qusetionName +'</p>'+
                '<p class="card-text">Action: '+qusetionsListResult[i].approved +'</p>'+
                '<p class="card-text"><small class="text-muted"> Qusetion Created: '+timeDifference(new Date(), new Date(qusetionsListResult[i].createdDate)) +'</small></p>';
                if(qusetionsListResult[i].Answer.length > 0){
                    str += 'Answers: '  
                    for (let j = 0; j < qusetionsListResult[i].Answer.length; j++) {  
                        str +='<p>'+(j+1)+'. '+qusetionsListResult[i].Answer[j].Answer+'</p>';
                        str+= '<label>'+"Comment"+' <textarea id="comment" name="comment"></textarea> </label>'+
                        '<button type="button" style="width:90px;" class="btn btn-primary btn-sm">Add Comment</button>'+
                       ' <i class="fa-solid fa-thumbs-up"></i><span class="ml-1">Like</span>'+
                       '<i class="fa fa-share"></i><span class="ml-1">Share</span>';
                      
                        
                       
                      
                        
                        
                       {/*  <div class="bg-white">
                    <div class="d-flex flex-row fs-12">
                        <div class="like p-2 cursor"><i class="fa fa-thumbs-o-up"></i><span class="ml-1">Like</span></div>
                        <div class="like p-2 cursor"><i class="fa fa-commenting-o"></i><span class="ml-1">Comment</span></div>
                        <div class="like p-2 cursor"><i class="fa fa-share"></i><span class="ml-1">Share</span></div>
                    </div>
                </div>
                <div class="bg-light p-2">
                    <div class="d-flex flex-row align-items-start"><img class="rounded-circle" src="https://i.imgur.com/RpzrMR2.jpg" width="40"><textarea class="form-control ml-1 shadow-none textarea"></textarea></div>
                    <div class="mt-2 text-right"><button class="btn btn-primary btn-sm shadow-none" type="button">Post comment</button><button class="btn btn-outline-primary btn-sm ml-1 shadow-none" type="button">Cancel</button></div>
                </div> */}

                    }
                }
                str += '</div>';
            }
            }
            str += '</div></div>';
           
 
    document.getElementById("qusetions").innerHTML = str;
}

getQusetions();
